import React, { useState } from 'react'

function Form() {

    const [psd, setPsd] = useState("");
  const [cpsd, setcPsd] = useState("");

  // Function to validate password strength
  const validpsd = (password) => {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);
  };






  const handleSubmit = () => {

    let inputs = document.querySelectorAll('.form-control')

    for(let input of inputs)
    {
        if(input.value == "")
        {
            alert("Please Fill All the Required Detials...!")
            return
        }
    }
   
    if (!validpsd(psd)) {
      alert("Password must be at least 8 characters and contain uppercase, lowercase, number, and a special character.");
      return
    }

    
    if (psd !== cpsd) {
      alert("Passwords do not match!");
      return;
    }

    alert("Password confirmed and valid!");
  };

    return (
        <>
            <h1>USER REGISTRATION</h1>


            <div className='container bg-info text-start rounded-5 p-2'>
                <form className='w-50 m-auto'>
                    <div className="mb-3">
                        <label  className="form-label">Email address :</label>
                        <input type="email" required className="form-control" id="exampleInputEmail10" aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Password :</label>
                        <input type="text"  value={psd} onChange={(e)=>{setPsd(e.target.value)}} required className="form-control" id="exampleInputPassword11" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label"> Retry Password :</label>
                        <input type="text" value={cpsd} onChange={(e)=>{setcPsd(e.target.value)}} required className="form-control" id="exampleInputPassword1" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">First Name :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword2" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Last Name :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword3" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Phone Number :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword4" /> <div className="mb-3">
                       
                    </div>
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Address :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword5" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Town :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword6" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Region :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword7" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Postcode / Zip :</label>
                        <input type="text" required className="form-control" id="exampleInputPassword8" />
                    </div>
                    <div className="mb-3">
                        <label  className="form-label">Country :</label>
                        <select  className="form-control" id="exampleInputPassword9">
                            <option>India</option>
                            <option>Canada</option>
                            <option>USA</option>
                            <option>Pakistan</option>
                        </select>
                        {/* <input type="text"  required className="form-control" id="exampleInputPassword1" /> */}
                    </div>
                   
                    <button type="submit" onClick={handleSubmit} className="btn btn-primary">Register</button>
                </form>
            </div>
        </>
    )
}

export default Form
                        


