import React, { createContext, useContext, useEffect, useState } from 'react'

const store = createContext()


function Display() {

    const [data, setData] = useState([])
    const [prd, setPrd] = useState([])


    useEffect(() => {
        fetch('http://localhost:1234/data')
            .then((res) => { return res.json() })
            .then((data) => { setData(data) })
    }, [])


    const handleAdd = (value) => {
        const Product = prd.find((item) => item.id == value.id);

       
        
        if(Product)
        {
          setPrd(prd.map((item)=>
             item.id == value.id ?
             {...item , qty : item.qty + 1 , totoalprice: (item.qty + 1) * item.price} : item
          )) 
        }
        else
        {
          setPrd([...prd,{...value,qty:1 , totoalprice: value.price}])
        }
              
      };






    return (
        <>
            <h2>Products</h2>


            <div className='container'>
                <div className='row'>
                    {data.map((value) => {
                        return (
                            <div className='col-xl-3' key={value.id}>
                                <div className="card" style={{ width: '18rem' }}>
                                    <div className="card-body">
                                        <h5 className="card-title">{value.name}</h5>
                                        <p className="card-text">{value.price}</p>
                                        <button onClick={() => { handleAdd(value) }}>Add To Cart</button>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
            <store.Provider value={prd}>
                <Products></Products>
            </store.Provider>
        </>
    )
}


function Products() {

    const data = useContext(store)

    return (
        <>
            {data.map((value) => {
                return (

                    <div className="card m-auto mt-5" key={value.id} style={{ width: '18rem' }}>
                        <div className="card-body">
                            <h5 className="card-title">{value.name}</h5>
                            <p className="card-text">{value.price}</p>
                            <p className="card-text">Quantity: {value.qty}</p>
                            <p className="card-text"><strong>Total: ${value.totoalprice}</strong></p>
                        </div>
                    </div>
                )
            })}
        </>
    )
}

export default Display











