import logo from './logo.svg';
import './App.css';
import Display from './Display';

function App() {
  return (
    <div className="App">
      <h1>Assessment Add to Cart</h1>

      <Display></Display>
    </div>
  );
}

export default App;
